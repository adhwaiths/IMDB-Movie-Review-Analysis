"""
           NLP IMDB Movie Reviews Challenge
"""
import hashlib
import pickle
import os
from matplotlib.testing.compare import compare_images
import matplotlib.pyplot as plt
# define Python user-defined exceptions


class Error(Exception):
    """Base class for other exceptions"""
    pass


class ResultDataShapeNotMatchError(Error):
    """Raised when the result dataset shape is not matched"""
    pass


class ResultValueNotMatchError(Error):
    """Raised when the function result values is not matched"""
    pass


class ResultTypeNotMatchError(Error):
    """Raised when the result data type is not matched"""
    pass


def geth(obj):
    obj = str(obj).encode()
    m = hashlib.md5()
    m.update(bytes(obj))
    return m.hexdigest()


class Answer:
    def __save_ans(self, ansNo, obj, back_ward_dir='../'):
        with open(back_ward_dir + ".ans/ans" + ansNo + ".pckl", 'wb') as f:
            pickle.dump(obj, f)

    def __get_ans(self, ansNo):
        ans = None
        try:
            with open(".ans/ans" + ansNo + ".pckl", "rb") as f:
                ans = pickle.load(f)
        except FileNotFoundError:
            return None
        return ans

expercted_dir = 'expected_img/'
score = False 

def compare_plots1(expected, actual):
    result = compare_images(expected, actual, tol=10)
    if result is None:
        score = True
    else:
        score = False
    return score

ansobj = Answer()

ans = ["ansobj._Answer__save_ans('1', aobj, '')", "ansobj._Answer__save_ans('2', aobj, '')",
       "ansobj._Answer__save_ans('3', aobj, '')", "ansobj._Answer__save_ans('4', aobj, '')", "ansobj._Answer__save_ans('5', aobj, '')",
       "ansobj._Answer__save_ans('6', aobj, '')", "ansobj._Answer__save_ans('7', aobj, '')", "ansobj._Answer__save_ans('8', aobj, '')",
       "ansobj._Answer__save_ans('9', aobj, '')", "ansobj._Answer__save_ans('10', aobj, '')", "ansobj._Answer__save_ans('11', aobj, '')",
       "ansobj._Answer__save_ans('12', aobj, '')"]
gans = ["ansobj._Answer__get_ans('1')", "ansobj._Answer__get_ans('2')",
        "ansobj._Answer__get_ans('3')", "ansobj._Answer__get_ans('4')", "ansobj._Answer__get_ans('5')", "ansobj._Answer__get_ans('6')", "ansobj._Answer__get_ans('7')", "ansobj._Answer__get_ans('8')",
        "ansobj._Answer__get_ans('9')", "ansobj._Answer__get_ans('10')", "ansobj._Answer__get_ans('11')", "ansobj._Answer__get_ans('12')"]

texts = ["test1 passed", "test1 failed", "test2 passed", "test2 failed", "test3 passed",
         "test3 failed", "test4 passed", "test4 failed", "test5 passed", "test5 failed", "test6 passed", "test6 failed",
         "test7 passed", "test7 failed", "test8 passed", "test8 failed", "test9 passed", "test9 failed", "test10 passed", "test10 failed",
         "test11 passed", "test11 failed", "test12 passed", "test12 failed"]


def usrans(filename):
    with open(filename, 'rb') as f:
        return pickle.load(f)


def test_nb(usrans, expected):
    assert usrans == expected
