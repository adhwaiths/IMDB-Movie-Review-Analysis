"""
      NLP IMDB Movie 
"""

from . import *
import warnings
import os
import pandas as pd
import numpy as np
import pkg_resources
warnings.simplefilter(action='ignore', category=FutureWarning)


def save_answer(data, clean_text,X, y, tfidf_vectorizer,X_train, X_test, y_train, y_test,svm, y_pred, accuracy, report, wc_dict, avg_word_length):
    remove_pickle()
    save_ans1(data, clean_text, X, y)
    save_ans2(tfidf_vectorizer, X_train, X_test, y_train, y_test)
    save_ans3(svm, y_pred)
    save_ans4(accuracy, report)
    save_ans5(wc_dict, avg_word_length)


def remove_pickle():
    try:
        os.mkdir('.ans')
    except:
        pass
    dir = '.ans/'
    for f in os.listdir(dir):
        os.remove(os.path.join(dir, f))


def save_ans1(data, clean_text, X, y):
    """
    Used to save test 1
    """
    col_list = ['clean_review', 'review', 'sentiment']
    flag = 0
    try:
        if (str(type(data)) == "<class 'pandas.core.frame.DataFrame'>") and (len(data) == 2000):
            flag = 1
        
        if callable(clean_text) and flag == 1:
            flag = 2
        
        if (str(type(X)) == "<class 'pandas.core.series.Series'>") and (str(type(y)) == "<class 'pandas.core.series.Series'>") and flag == 2:
            flag = 3
        
        if sorted(list(data.columns)) == sorted(col_list) and flag == 3:
            flag = 4

        if flag == 4:
            aobj = geth(texts[0])
            print("Test Case 1 Passed")
            eval(ans[0])
        else:
            aobj = geth(texts[1])
            print("Test Case 1 Failed")
            eval(ans[0])

    except:
        print('Test Case 1 Failed')
        aobj = geth(texts[1])
        eval(ans[0])


def save_ans2(tfidf_vectorizer, X_train, X_test, y_train, y_test):
    """
    Used to save test 2
    """
    flag = 0
    try:
    
        if str(type(tfidf_vectorizer)) == "<class 'sklearn.feature_extraction.text.TfidfVectorizer'>":
            flag = 1

        if (X_train is not None) and (X_test is not None) and (y_train is not None) and (y_test is not None) and flag == 1:
            flag = 2

        if flag == 2:
            aobj = geth(texts[2])
            print("Test Case 2 Passed")
            eval(ans[1])
        else:
            aobj = geth(texts[3])
            print("Test Case 2 Failed")
            eval(ans[1])

    except:
        print('Test Case 2 Failed')
        aobj = geth(texts[3])
        eval(ans[1])


def save_ans3(svm, y_pred):
    """
    Used to save test 3
    """
    flag = 0
    try:

        if str(type(svm)) == "<class 'sklearn.svm._classes.LinearSVC'>" :
            flag = 1
        
        if len(y_pred) == 400 and flag == 1:
            flag = 2

        if flag == 2:
            aobj = geth(texts[4])
            print("Your answer has been saved")
            eval(ans[2])
        else:
            aobj = geth(texts[5])
            print("Your answer has been saved")
            eval(ans[2])
    except:
        print('Please review variables/Return types')
        aobj = geth(texts[5])
        eval(ans[2])


def save_ans4(accuracy, report):
    """
    Used to save test 4
    """
    rep = {'negative': {'precision': 0.8316326530612245,
    'recall': 0.8358974358974359,
    'f1-score': 0.8337595907928389,
    'support': 195},
    'positive': {'precision': 0.8431372549019608,
    'recall': 0.8390243902439024,
    'f1-score': 0.8410757946210269,
    'support': 205},
    'accuracy': 0.8375,
    'macro avg': {'precision': 0.8373849539815926,
    'recall': 0.8374609130706692,
    'f1-score': 0.8374176927069329,
    'support': 400},
    'weighted avg': {'precision': 0.8375287615046019,
    'recall': 0.8375,
    'f1-score': 0.8375091452547853,
    'support': 400}}
    flag = 0
    try:   
        
        if float(accuracy) >= float(0.80):
            flag = 1
        
        if sorted(report) == sorted(rep) and flag == 1:
            flag = 2

        if flag == 2:
            aobj = geth(texts[6])
            print("Your answer has been saved")
            eval(ans[3])
        else:
            aobj = geth(texts[7])
            print("Your answer has been saved")
            eval(ans[3])
    except:
        print('Please review variables/Return types')
        aobj = geth(texts[7])
        eval(ans[3])


def save_ans5(wc_dict, avg_word_length):
    """
    Used to save test 5
    """
    dict = {'movie': 3321,
    'film': 2851,
    'one': 1762,
    'like': 1433,
    'good': 1051,
    'would': 965,
    'see': 919,
    'even': 879,
    'really': 857,
    'story': 840}

    flag = 0
    try:   

        if sorted(wc_dict) == sorted(dict):
            flag = 1
        
        if round(avg_word_length) == 6 and flag == 1:
            flag = 2
        
        if flag == 2:
            aobj = geth(texts[8])
            eval(ans[4])
            print("Your answer has been saved")
        else:
            aobj = geth(texts[9])
            print("Your answer has been saved")
            eval(ans[4])
    except:
        print('Please review variables/Return types')
        aobj = geth(texts[9])
        eval(ans[4])
